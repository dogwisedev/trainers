import Link from "next/link";
import { CalendarPlus } from "lucide-react";
import { getTrainer, listBookings, listTimeOff, requireRole } from "@/lib/data";
import { soonestOpening, weekUsage } from "@/lib/capacity";
import { addDays, daysBetween, range, short, todayIso, weekStart, weeksFrom } from "@/lib/dates";
import { KennelLegend, KennelStrip } from "@/components/KennelStrip";
import { Empty, Pill, Section } from "@/components/ui";
import { listTodos } from "@/lib/reportData";
import { readinessFor } from "@/lib/pretraining";
import { isDemo, serviceClient } from "@/lib/supabase";
import type { Booking } from "@/lib/types";
import { Info } from "lucide-react";
import { contactFrom } from "@/lib/contactLinks";
import { TodayVisits, type Visit } from "@/components/TodayVisits";
import { CONFIRM_FROM } from "@/lib/moveRules";
import { trainerToday } from "@/lib/trainerToday";
import { TrainerTodo } from "@/components/TrainerTodo";

export default async function TrainerHome() {
  const v = await requireRole("trainer");
  const t = v.trainerId ? await getTrainer(v.trainerId) : null;
  if (!t) return <Empty title="Your login isn't linked to a trainer profile yet.">Message the Dogwise team and they'll link it.</Empty>;
  const today = todayIso();
  const [bookings, off] = await Promise.all([listBookings({ trainerId: t.id, from: addDays(today, -7) }), listTimeOff({ trainerId: t.id, from: today })]);
  const use = weekUsage(t, bookings, off, weeksFrom(today, 12));
  const now = use[0];
  const withYou = bookings.filter((b) => b.status !== "cancelled" && b.start_date <= today && b.end_date >= today);
  const next = bookings.filter((b) => b.status !== "cancelled" && b.start_date > today).slice(0, 4);
  const open3 = soonestOpening(use, 3);
  const first = t.name.replace(/".*?"\s*/, "").split(" ")[0];
  const [todo, todayList] = await Promise.all([listTodos({ trainerId: t.id }).then((l) => l.filter((x) => x.state !== "waiting")), trainerToday(t.id, t.state)]);
  // Before-training checklist per dog, linking to the chat's Dog profile
  const shownIds = [...withYou, ...next].map((b) => b.id);
  const ready = await readinessFor(shownIds);
  const deals = [...new Set([...withYou, ...next].map((b) => b.hubspot_deal_id).filter((x): x is string => !!x))];
  const { data: chatRows } = deals.length && !isDemo() ? await serviceClient().from("chats").select("id, deal_key").in("deal_key", deals).eq("trainer_id", t.id).eq("status", "open") : { data: [] };
  const chatOf = new Map(((chatRows || []) as { id: string; deal_key: string }[]).map((c) => [c.deal_key, c.id]));
  const readyBadge = (b: Booking) => {
    const r = ready.get(b.id), chat = b.hubspot_deal_id ? chatOf.get(b.hubspot_deal_id) : null;
    if (!r || !chat) return null;
    const n = r.ready.missing.length;
    return <Link prefetch={false} href={`/t/chats/${chat}/profile?dog=${b.id}`} className={`rounded-full px-2.5 py-0.5 text-caption font-bold ${n ? "bg-heart-wash text-heart" : "bg-mint-wash text-fern"}`}>{n ? `${n} to do before training` : "Ready"}</Link>;
  };

  // Today's pickups and drop-offs, with the client's address from their forms (one row per client, all their dogs)
  // Today's pickups and drop-offs, plus any earlier one still not confirmed (they stay here until the trainer taps or the form is in)
  const pick = (b: Booking) => b.status !== "cancelled" && (b.start_date === today || (b.start_date < today && b.start_date >= CONFIRM_FROM && !(b as { picked_up_at?: string | null }).picked_up_at));
  const home = (b: Booking) => b.status !== "cancelled" && (b.end_date === today || (b.end_date < today && b.end_date >= CONFIRM_FROM && !!(b as { picked_up_at?: string | null }).picked_up_at && !(b as { dropped_off_at?: string | null }).dropped_off_at));
  const visitsRaw = bookings.filter((b) => pick(b) || home(b));
  const visitDeals = [...new Set(visitsRaw.map((b) => b.hubspot_deal_id).filter((x): x is string => !!x && /^\d+$/.test(x)))];
  const { data: contacts } = visitDeals.length && !isDemo() ? await serviceClient().from("pretraining_deals").select("deal_id, contact").in("deal_id", visitDeals) : { data: [] };
  const contactOf = new Map(((contacts || []) as { deal_id: string; contact: Record<string, unknown> | null }[]).map((r) => [r.deal_id, r.contact]));
  const grouped = new Map<string, Visit>();
  for (const b of visitsRaw) for (const kind of ([pick(b) ? "pickup" : null, home(b) ? "home" : null].filter(Boolean) as Visit["kind"][])) {
    const k = `${kind}:${b.hubspot_deal_id || b.id}`;
    const c = contactFrom(b.hubspot_deal_id ? contactOf.get(b.hubspot_deal_id) : null, b.client_name);
    const done = kind === "pickup" ? (b as { picked_up_at?: string | null }).picked_up_at : (b as { dropped_off_at?: string | null }).dropped_off_at;
    const x = grouped.get(k);
    if (x) { x.dogs = `${x.dogs} & ${b.dog_name || "Dog"}`; x.bookingIds.push(b.id); x.confirmed = x.confirmed && !!done; continue; }
    grouped.set(k, { key: k, kind, dogs: b.dog_name || "Dog", bookingId: b.id, bookingIds: [b.id], client: c.name || b.client_name, address: c.address, phone: c.phone,
      day: kind === "pickup" ? b.start_date : b.end_date, today, confirmed: !!done, canConfirm: (kind === "pickup" ? b.start_date : b.end_date) >= CONFIRM_FROM });
  }
  const visits = [...grouped.values()].sort((a, b) => (a.kind === b.kind ? 0 : a.kind === "pickup" ? -1 : 1));
  const infoLink = (b: Booking) => <Link prefetch={false} href={`/t/dogs/${b.id}`} className="btn-ghost h-10 min-h-0 shrink-0 px-3 text-body"><Info size={16} />Info</Link>;

  return (
    <>
      <TodayVisits visits={visits} today={today} />
      <TrainerTodo today={todayList} forms={todo} />
      <div className="rounded-[28px] bg-mint p-5 md:p-7" data-tour="week">
        <p className="text-body text-ink-soft">{new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</p>
        <h1 className="mt-1 text-h1 font-extrabold leading-tight md:text-display">Hi {first}</h1>
        <p className="mt-2 text-lead">
          {now.dogs.length ? `${now.dogs.length} dog${now.dogs.length > 1 ? "s" : ""} with you this week` : "No dogs with you this week"}
          {now.blocked >= now.cap && now.cap > 0 ? ", and you're marked as away." : `, ${now.free} kennel${now.free === 1 ? "" : "s"} free.`}
        </p>
        <div className="mt-5 rounded-[20px] bg-white/70 p-4">
          <KennelStrip use={use} />
          <KennelLegend />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="panel p-4"><p className="text-small text-ink-soft">Dogs at one time</p><p className="text-h1 font-extrabold">{t.capacity}</p></div>
        <div className="panel p-4"><p className="text-small text-ink-soft">Next 3-week opening</p><p className="text-h2 font-extrabold leading-9">{open3 ? (open3 === weekStart(today) ? "Now" : short(open3)) : "Full"}</p></div>
      </div>


      <Section tour="with-you" title="With you now">
        {withYou.length ? (
          <ul className="space-y-2.5">
            {withYou.map((b) => {
              const total = Math.max(1, daysBetween(b.start_date, b.end_date)), done = Math.min(total, daysBetween(b.start_date, today) + 1);
              return (
                <li key={b.id} className="panel p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div><p className="text-lead font-bold">{b.dog_name || "Dog"}</p><p className="text-body text-ink-soft">{b.client_name}, {range(b.start_date, b.end_date)}</p></div>
                    <div className="flex shrink-0 flex-col items-end gap-2"><Pill tone="biscuit">Week {Math.ceil(done / 7)} of {Math.ceil(total / 7)}</Pill>{infoLink(b)}</div>
                  </div>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-paper"><div className="h-full rounded-full bg-biscuit" style={{ width: `${(done / total) * 100}%` }} /></div>
                  {b.notes && <p className="mt-3 text-body text-ink-soft">{b.notes}</p>}
                  {readyBadge(b) && <div className="mt-2">{readyBadge(b)}</div>}
                </li>
              );
            })}
          </ul>
        ) : <Empty title="No dogs in training right now." />}
      </Section>

      <Section title="Coming up">
        {next.length ? (
          <ul className="panel divide-y divide-line">
            {next.map((b) => (
              <li key={b.id} className="flex items-center justify-between gap-3 p-4">
                <div><p className="font-semibold">{b.dog_name || "Dog"} <span className="font-normal text-ink-soft">with {b.client_name}</span></p><p className="text-body text-ink-soft">{range(b.start_date, b.end_date)}</p>{readyBadge(b) && <div className="mt-1">{readyBadge(b)}</div>}</div>
                <div className="flex shrink-0 flex-col items-end gap-2"><Pill tone={b.status === "pending" ? "line" : "mint"}>{b.status === "pending" ? "Pending" : "Confirmed"}</Pill>{infoLink(b)}</div>
              </li>
            ))}
          </ul>
        ) : <Empty title="Nothing booked yet." >New dogs show up here as soon as they're booked.</Empty>}
        <span className="mt-3 flex gap-4 text-body font-semibold"><Link prefetch={false} href="/t/past" className="underline">Past dogs</Link><Link prefetch={false} href="/t/followup" className="underline">Log a follow-up session</Link></span>
      </Section>

      <Section title="Time off" action={<Link prefetch={false} href="/t/calendar#time-off" className="btn-mint h-10 min-h-0 px-3 text-body"><CalendarPlus size={16} />Block dates</Link>}>
        {off.length ? (
          <ul className="panel divide-y divide-line">
            {off.slice(0, 4).map((o) => (
              <li key={o.id} className="flex items-center justify-between p-4"><span>{range(o.start_date, o.end_date)}</span><Pill tone="heart">{o.slots_blocked ? `${o.slots_blocked} kennel${o.slots_blocked > 1 ? "s" : ""}` : o.reason}</Pill></li>
            ))}
          </ul>
        ) : <p className="text-body text-ink-soft">No time off booked.</p>}
      </Section>
    </>
  );
}
